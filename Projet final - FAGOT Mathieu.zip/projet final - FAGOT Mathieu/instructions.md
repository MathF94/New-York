# Exercice final: New York

## Largeur
Largeur du contenu du site : 980px

## Polices de caractère
- Source San Pro par défaut (Google font), 
- Courgette : titres, menu et citation. Le fichier de la police est fourni, mais dans sa version compatible pour le print. Il sera nécessaire de la convertir pour le web.

## Taille des textes
Par défaut : 18px
Titre du site : 40px
Titres rubriques :  35px
Titres sous-rubriques : 25px
Citation : 25px
Copyright : 14px

## Couleurs
Texte : #444
bleu foncé : #003884 
bleu moyen : #4f89b9
fond de la citation : #d7e1ef

## Liens
Les liens des rubriques du menu amènent directement aux rubriques auxquelles elles correspondent.
Le lien du pied de page renvoi sur les conditions d'utilisation du matériel pédagogique de la 3WA : "https://3wa.fr/propriete-materiel-pedagogique/
